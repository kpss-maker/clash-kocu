
function yanMenuyuAc() {
  document.getElementById('yanMenu').style.left = '0';
}
function yanMenuyuKapat() {
  document.getElementById('yanMenu').style.left = '-200px';
}

window.addEventListener('DOMContentLoaded', () => {
  fetch('taktikler.json')
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById('taktik-videolari');
      data.forEach(item => {
        const div = document.createElement('div');
        div.className = 'video-item';
        div.innerHTML = `<h3>${item.baslik}</h3><iframe width="100%" height="215" src="${item.link}" frameborder="0" allowfullscreen></iframe>`;
        container.appendChild(div);
      });
    });

  fetch('duzenler.json')
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById('duzen-kartlari');
      data.forEach(item => {
        const div = document.createElement('div');
        div.className = 'duzen-kart';
        div.innerHTML = `<h3>${item.th} - ${item.baslik}</h3>
                         <img src="${item.gorsel}" alt="Düzen" style="width:100%;max-width:400px;">
                         <p>${item.aciklama || ''}</p>`;
        container.appendChild(div);
      });
    });
});
